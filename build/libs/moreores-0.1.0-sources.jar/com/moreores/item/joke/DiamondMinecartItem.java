package com.moreores.item.joke;

import net.minecraft.class_1269;
import net.minecraft.class_1695;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;

/**
 * Diamond Minecart - a special minecart that displays a diamond block.
 * Creative joke item - place on rail to spawn a minecart with diamond block display.
 */
public class DiamondMinecartItem extends class_1792 {

    public DiamondMinecartItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 pos = context.method_8037();
        class_2680 state = world.method_8320(pos);

        if (!(state.method_26204() instanceof class_2241)) {
            return class_1269.field_5814;
        }

        if (!world.field_9236) {
            class_1695 minecart = new class_1695(world, pos.method_10263() + 0.5, pos.method_10264() + 0.0625, pos.method_10260() + 0.5);

            // Set custom display block (diamond block) via NBT
            class_2487 nbt = new class_2487();
            minecart.method_5647(nbt);
            // DisplayTile stores the block state ID for the displayed block
            nbt.method_10569("DisplayTile", net.minecraft.class_7923.field_41175.method_10206(
                    net.minecraft.class_2246.field_10201));
            nbt.method_10569("DisplayOffset", 6);
            minecart.method_5651(nbt);

            minecart.method_5665(net.minecraft.class_2561.method_43471("item.moreores.diamond_minecart"));

            world.method_8649(minecart);
            if (!context.method_8036().method_7337()) {
                context.method_8041().method_7934(1);
            }
        }

        return class_1269.field_5812;
    }
}
