package com.moreores.item.joke;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;

/**
 * Golden Apple Juice - drinkable item giving Absorption IV and Regeneration IV for 30 seconds each.
 */
public class GoldenAppleJuiceItem extends class_1792 {

    public GoldenAppleJuiceItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public net.minecraft.class_1839 method_7853(class_1799 stack) {
        return net.minecraft.class_1839.field_8946;
    }

    @Override
    public int method_7881(class_1799 stack) {
        return 32;
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (!world.field_9236 && user instanceof class_1657 player) {
            // Absorption IV for 30 seconds (600 ticks)
            player.method_6092(new class_1293(class_1294.field_5898, 600, 3));
            // Regeneration IV for 30 seconds (600 ticks)
            player.method_6092(new class_1293(class_1294.field_5924, 600, 3));

            if (!player.method_7337()) {
                stack.method_7934(1);
            }
        }
        return stack.method_7960() ? new class_1799(class_1802.field_8469) : stack;
    }

    @Override
    public net.minecraft.class_1271<class_1799> method_7836(class_1937 world, class_1657 user, net.minecraft.class_1268 hand) {
        user.method_6019(hand);
        return net.minecraft.class_1271.method_22428(user.method_5998(hand));
    }
}
