package com.moreores.item.joke;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_3965;

/**
 * Barrier Boat - a creative-mode joke boat.
 * Spawns a regular oak boat with a custom name as a humorous item.
 */
public class BarrierBoatItem extends class_1792 {

    public BarrierBoatItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (!world.field_9236) {
            class_239 hit = user.method_5745(5.0, 0f, true);
            double x = user.method_23317();
            double y = user.method_23318();
            double z = user.method_23321();

            if (hit instanceof class_3965 blockHit) {
                class_2338 pos = blockHit.method_17777();
                x = pos.method_10263() + 0.5;
                y = pos.method_10264() + 1.0;
                z = pos.method_10260() + 0.5;
            }

            class_1690 boat = new class_1690(world, x, y, z);
            boat.method_5665(class_2561.method_43471("item.moreores.barrier_boat"));
            boat.method_5880(true);

            world.method_8649(boat);
            if (!user.method_7337()) {
                stack.method_7934(1);
            }
        }

        return class_1271.method_22427(stack);
    }
}
