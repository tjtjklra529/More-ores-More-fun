package com.moreores.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import java.util.UUID;
import net.minecraft.class_1304;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_5134;

/**
 * A dagger: faster than a sword but deals less damage.
 * Attack speed modifier: -2.0 (versus sword's -2.4 means daggers attack faster).
 */
public class DaggerItem extends class_1829 {

    private static final UUID DAGGER_ATTACK_SPEED_UUID = UUID.fromString("FA233E1C-4180-4865-B01B-BCCE9785ACA3");
    private static final UUID DAGGER_ATTACK_DAMAGE_UUID = UUID.fromString("CB3F55D3-645C-4F38-A497-9C13A33DB5CF");

    private final float attackDamageBonus;
    private final float attackSpeed;
    private final Multimap<class_1320, class_1322> attributeModifiers;

    public DaggerItem(class_1832 toolMaterial, int attackDamageBonus, float attackSpeed, class_1793 settings) {
        super(toolMaterial, attackDamageBonus, attackSpeed, settings);
        this.attackDamageBonus = attackDamageBonus;
        this.attackSpeed = attackSpeed;

        float totalDamage = toolMaterial.method_8028() + attackDamageBonus;

        ImmutableMultimap.Builder<class_1320, class_1322> builder = ImmutableMultimap.builder();
        builder.put(class_5134.field_23721,
                new class_1322(DAGGER_ATTACK_DAMAGE_UUID,
                        "Weapon modifier", totalDamage, class_1322.class_1323.field_6328));
        builder.put(class_5134.field_23723,
                new class_1322(DAGGER_ATTACK_SPEED_UUID,
                        "Weapon modifier", attackSpeed, class_1322.class_1323.field_6328));
        this.attributeModifiers = builder.build();
    }

    @Override
    public Multimap<class_1320, class_1322> method_7844(class_1304 slot) {
        if (slot == class_1304.field_6173) {
            return attributeModifiers;
        }
        return super.method_7844(slot);
    }
}
