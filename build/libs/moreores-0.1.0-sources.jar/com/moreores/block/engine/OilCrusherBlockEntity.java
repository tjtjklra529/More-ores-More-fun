package com.moreores.block.engine;

import com.moreores.registry.ModBlockEntities;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1277;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class OilCrusherBlockEntity extends class_2586 {

    public static final int PROCESSING_TICKS = 100;

    // Maps raw ore item name -> output ingot item name
    private static final Map<String, String> CRUSH_RECIPES = new HashMap<>();

    static {
        CRUSH_RECIPES.put("moreores:raw_titanium", "moreores:titanium_ingot");
        CRUSH_RECIPES.put("moreores:raw_platinum", "moreores:platinum_ingot");
        CRUSH_RECIPES.put("moreores:raw_nickel", "moreores:nickel_ingot");
        CRUSH_RECIPES.put("moreores:raw_aluminum", "moreores:aluminum_ingot");
        CRUSH_RECIPES.put("moreores:raw_silver", "moreores:silver_ingot");
        CRUSH_RECIPES.put("moreores:raw_tin", "moreores:tin_ingot");
        // Vanilla raws
        CRUSH_RECIPES.put("minecraft:raw_iron", "minecraft:iron_ingot");
        CRUSH_RECIPES.put("minecraft:raw_gold", "minecraft:gold_ingot");
        CRUSH_RECIPES.put("minecraft:raw_copper", "minecraft:copper_ingot");
    }

    public class_1277 inventory = new class_1277(2); // slot 0 = input, slot 1 = output
    private int progress = 0;

    public OilCrusherBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.OIL_CRUSHER, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, OilCrusherBlockEntity be) {
        if (world.field_9236) return;

        if (!isAdjacentEngineActive(world, pos)) {
            be.progress = 0;
            return;
        }

        class_1799 input = be.inventory.method_5438(0);
        if (input.method_7960()) {
            be.progress = 0;
            return;
        }

        String inputId = class_7923.field_41178.method_10221(input.method_7909()).toString();
        String outputId = CRUSH_RECIPES.get(inputId);
        if (outputId == null) {
            be.progress = 0;
            return;
        }

        class_1792 outputItem = class_7923.field_41178.method_10223(new class_2960(outputId));
        class_1799 outputStack = be.inventory.method_5438(1);

        // Check output slot can accept 2 more items
        boolean canOutput = outputStack.method_7960() ||
                (outputStack.method_7909() == outputItem && outputStack.method_7947() + 2 <= outputStack.method_7914());

        if (!canOutput) {
            be.progress = 0;
            return;
        }

        be.progress++;

        if (be.progress >= PROCESSING_TICKS) {
            be.progress = 0;
            input.method_7934(1);

            // Output 2 ingots
            if (outputStack.method_7960()) {
                be.inventory.method_5447(1, new class_1799(outputItem, 2));
            } else {
                outputStack.method_7933(2);
            }
            be.method_5431();
        }
    }

    public static boolean isAdjacentEngineActive(class_1937 world, class_2338 pos) {
        for (class_2350 dir : class_2350.values()) {
            class_2338 neighborPos = pos.method_10093(dir);
            if (world.method_8320(neighborPos).method_26204() instanceof OilEngineBlock) {
                class_2586 be = world.method_8321(neighborPos);
                if (be instanceof OilEngineBlockEntity engine) {
                    return engine.isActive();
                }
            }
        }
        return false;
    }

    public int getProgress() {
        return progress;
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        progress = nbt.method_10550("Progress");
        class_2487 invNbt = nbt.method_10562("Inventory");
        class_1799 input = class_1799.method_7915(invNbt.method_10562("Input"));
        class_1799 output = class_1799.method_7915(invNbt.method_10562("Output"));
        inventory.method_5447(0, input);
        inventory.method_5447(1, output);
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        nbt.method_10569("Progress", progress);
        class_2487 invNbt = new class_2487();
        invNbt.method_10566("Input", inventory.method_5438(0).method_7953(new class_2487()));
        invNbt.method_10566("Output", inventory.method_5438(1).method_7953(new class_2487()));
        nbt.method_10566("Inventory", invNbt);
    }
}
