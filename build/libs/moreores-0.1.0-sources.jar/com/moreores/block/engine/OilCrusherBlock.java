package com.moreores.block.engine;

import com.moreores.registry.ModBlockEntities;
import net.minecraft.block.*;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class OilCrusherBlock extends class_2237 {

    public OilCrusherBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new OilCrusherBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return world.field_9236 ? null : method_31618(type, ModBlockEntities.OIL_CRUSHER, OilCrusherBlockEntity::tick);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.field_9236) return class_1269.field_5812;

        class_2586 be = world.method_8321(pos);
        if (be instanceof OilCrusherBlockEntity crusher) {
            class_1799 heldStack = player.method_5998(hand);

            if (heldStack.method_7960()) {
                // Take output
                class_1799 output = crusher.inventory.method_5438(1);
                if (!output.method_7960()) {
                    player.method_7270(output.method_7972());
                    crusher.inventory.method_5447(1, class_1799.field_8037);
                    crusher.method_5431();
                    return class_1269.field_5812;
                }
            } else {
                // Try to insert input
                class_1799 input = crusher.inventory.method_5438(0);
                if (input.method_7960()) {
                    class_1799 toInsert = heldStack.method_7972();
                    toInsert.method_7939(1);
                    crusher.inventory.method_5447(0, toInsert);
                    if (!player.method_7337()) {
                        heldStack.method_7934(1);
                    }
                    crusher.method_5431();
                    return class_1269.field_5812;
                }
            }
        }
        return class_1269.field_5811;
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof OilCrusherBlockEntity crusher) {
                class_1264.method_5451(world, pos, crusher.inventory);
            }
        }
        super.method_9536(state, world, pos, newState, moved);
    }
}
