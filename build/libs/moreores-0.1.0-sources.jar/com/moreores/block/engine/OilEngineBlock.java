package com.moreores.block.engine;

import com.moreores.registry.ModBlockEntities;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class OilEngineBlock extends class_2237 {

    public static final class_2746 ACTIVE = class_2741.field_12548;

    public OilEngineBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(ACTIVE, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ACTIVE);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new OilEngineBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, ModBlockEntities.OIL_ENGINE, OilEngineBlockEntity::tick);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof OilEngineBlockEntity engine) {
                class_1799 stack = player.method_5998(hand);
                // Check for oil bucket (registered in mod)
                if (stack.method_7909() == class_1802.field_8550) {
                    // Check if it's an oil bucket by checking item tag or name
                    // We check registry name
                    String itemId = net.minecraft.class_7923.field_41178.method_10221(stack.method_7909()).toString();
                    if (itemId.equals("moreores:oil_bucket")) {
                        if (engine.getFuelTicks() < OilEngineBlockEntity.MAX_FUEL) {
                            engine.addFuel(OilEngineBlockEntity.MAX_FUEL);
                            if (!player.method_7337()) {
                                player.method_6122(hand, new class_1799(class_1802.field_8550));
                            }
                            world.method_8652(pos, state.method_11657(ACTIVE, true), 3);
                            return class_1269.field_5812;
                        }
                    }
                } else {
                    // Try to match oil bucket by name
                    String itemId = net.minecraft.class_7923.field_41178.method_10221(stack.method_7909()).toString();
                    if (itemId.equals("moreores:oil_bucket")) {
                        if (engine.getFuelTicks() < OilEngineBlockEntity.MAX_FUEL) {
                            engine.addFuel(OilEngineBlockEntity.MAX_FUEL);
                            if (!player.method_7337()) {
                                player.method_6122(hand, new class_1799(class_1802.field_8550));
                            }
                            world.method_8652(pos, state.method_11657(ACTIVE, true), 3);
                            return class_1269.field_5812;
                        }
                        return class_1269.field_21466;
                    }
                }
            }
        }
        return class_1269.field_5811;
    }

    @Override
    public boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    public int method_9572(class_2680 state, class_1937 world, class_2338 pos) {
        class_2586 be = world.method_8321(pos);
        if (be instanceof OilEngineBlockEntity engine) {
            return engine.getComparatorOutput();
        }
        return 0;
    }
}
