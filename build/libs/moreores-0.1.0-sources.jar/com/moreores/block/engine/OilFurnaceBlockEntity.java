package com.moreores.block.engine;

import com.moreores.registry.ModBlockEntities;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_3858;
import net.minecraft.class_3956;

public class OilFurnaceBlockEntity extends class_2609 {

    public OilFurnaceBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.OIL_FURNACE, pos, state, class_3956.field_17546);
    }

    @Override
    protected class_2561 method_17823() {
        return class_2561.method_43471("block.moreores.oil_furnace");
    }

    @Override
    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return new class_3858(syncId, playerInventory, this, this.field_17374);
    }

    /**
     * Server tick with oil-engine speed boost.
     * Calls parent tick, then if adjacent engine is active, calls it again for 2x speed.
     */
    public static void tick(class_1937 world, class_2338 pos, class_2680 state, OilFurnaceBlockEntity be) {
        // Standard furnace tick
        class_2609.method_31651(world, pos, state, be);

        // If adjacent oil engine is active, tick again for 2x speed
        if (isAdjacentEngineActive(world, pos)) {
            class_2609.method_31651(world, pos, state, be);
        }
    }

    public static boolean isAdjacentEngineActive(class_1937 world, class_2338 pos) {
        for (class_2350 dir : class_2350.values()) {
            class_2338 neighborPos = pos.method_10093(dir);
            if (world.method_8320(neighborPos).method_26204() instanceof OilEngineBlock) {
                net.minecraft.class_2586 be = world.method_8321(neighborPos);
                if (be instanceof OilEngineBlockEntity engine) {
                    return engine.isActive();
                }
            }
        }
        return false;
    }
}
