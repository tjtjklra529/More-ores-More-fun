package com.moreores.block.engine;

import com.moreores.registry.ModBlockEntities;
import net.minecraft.block.*;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2363;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class OilFurnaceBlock extends class_2363 {

    public OilFurnaceBlock(class_2251 settings) {
        super(settings);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new OilFurnaceBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return world.field_9236 ? null : method_31618(type, ModBlockEntities.OIL_FURNACE,
                (w, p, s, be) -> OilFurnaceBlockEntity.tick(w, p, s, be));
    }

    @Override
    protected void method_17025(class_1937 world, class_2338 pos, class_1657 player) {
        class_2586 be = world.method_8321(pos);
        if (be instanceof class_3908 factory) {
            player.method_17355(factory);
        }
    }
}
