package com.moreores.block.engine;

import com.moreores.registry.ModBlockEntities;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class OilEngineBlockEntity extends class_2586 {

    public static final int MAX_FUEL = 800;

    private int fuelTicks = 0;
    private boolean active = false;

    public OilEngineBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.OIL_ENGINE, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, OilEngineBlockEntity be) {
        if (world.field_9236) return;

        boolean wasActive = be.active;

        if (be.active) {
            if (be.fuelTicks > 0) {
                be.fuelTicks--;
                if (be.fuelTicks == 0) {
                    be.active = false;
                }
            } else {
                be.active = false;
            }
        }

        if (wasActive != be.active) {
            world.method_8652(pos, state.method_11657(OilEngineBlock.ACTIVE, be.active), 3);
        }

        if (wasActive != be.active || (be.active && be.fuelTicks % 20 == 0)) {
            be.method_5431();
        }
    }

    public int getFuelTicks() {
        return fuelTicks;
    }

    public boolean isActive() {
        return active;
    }

    public void addFuel(int ticks) {
        this.fuelTicks = Math.min(MAX_FUEL, this.fuelTicks + ticks);
        if (this.fuelTicks > 0) {
            this.active = true;
        }
        method_5431();
    }

    public void setActive(boolean active) {
        this.active = active;
        method_5431();
    }

    public int getComparatorOutput() {
        // 0-15 based on fuel level
        return (int) ((fuelTicks / (float) MAX_FUEL) * 15);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        fuelTicks = nbt.method_10550("FuelTicks");
        active = nbt.method_10577("Active");
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        nbt.method_10569("FuelTicks", fuelTicks);
        nbt.method_10556("Active", active);
    }
}
