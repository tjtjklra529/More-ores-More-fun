package com.moreores.fluid;

import com.moreores.registry.ModBlocks;
import com.moreores.registry.ModItems;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;

/**
 * Oil fluid: black, viscous. Slower spreading than water.
 */
public abstract class OilFluid extends net.minecraft.class_3609 {

    public static final Still STILL = new Still();
    public static final Flowing FLOWING = new Flowing();

    @Override
    public class_3611 method_15750() {
        return FLOWING;
    }

    @Override
    public class_3611 method_15751() {
        return STILL;
    }

    @Override
    public class_1792 method_15774() {
        class_1792 bucket = ModItems.ITEMS.get("oil_bucket");
        return bucket != null ? bucket : class_1802.field_8550;
    }

    @Override
    protected boolean method_15737(net.minecraft.class_1937 world) {
        return false;
    }

    @Override
    protected void method_15730(class_1936 world, class_2338 pos, class_2680 state) {
        // Break block silently
        world.method_22352(pos, true);
    }

    @Override
    protected int method_15733(class_4538 world) {
        // Slower spread than water (water is 4, oil is slightly slower)
        return 4;
    }

    @Override
    protected int method_15739(class_4538 world) {
        return 1;
    }

    @Override
    public class_2680 method_15790(class_3610 state) {
        return ModBlocks.OIL_FLUID_BLOCK.method_9564()
                .method_11657(net.minecraft.class_2404.field_11278, method_15741(state));
    }

    @Override
    public boolean method_15780(class_3611 fluid) {
        return fluid == STILL || fluid == FLOWING;
    }

    @Override
    protected class_2394 method_15787() {
        return class_2398.field_11223;
    }

    @Override
    public float method_15784() {
        return 100.0f;
    }

    @Override
    public int method_15789(net.minecraft.class_4538 world) {
        return 10;
    }

    @Override
    public boolean method_15777(class_3610 state, net.minecraft.class_1922 world,
                                     class_2338 pos, class_3611 fluid, class_2350 direction) {
        return false;
    }

    // --- Still ---

    public static class Still extends OilFluid {
        @Override
        public int method_15779(class_3610 state) {
            return 8;
        }

        @Override
        public boolean method_15793(class_3610 state) {
            return true;
        }

        @Override
        protected void method_15775(class_2689.class_2690<class_3611, class_3610> builder) {
            // No extra properties for still fluid
        }
    }

    // --- Flowing ---

    public static class Flowing extends OilFluid {
        @Override
        protected void method_15775(class_2689.class_2690<class_3611, class_3610> builder) {
            super.method_15775(builder);
            builder.method_11667(field_15900);
        }

        @Override
        public int method_15779(class_3610 state) {
            return state.method_11654(field_15900);
        }

        @Override
        public boolean method_15793(class_3610 state) {
            return false;
        }
    }
}
