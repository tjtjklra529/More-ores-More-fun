package com.moreores.fluid;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3609;

/**
 * The oil fluid block - what you see when oil fills a space in the world.
 */
public class OilFluidBlock extends class_2404 {

    public OilFluidBlock(class_3609 fluid, class_2251 settings) {
        super(fluid, settings);
    }

    @Override
    public int method_9505(class_2680 state, class_1922 world, class_2338 pos) {
        return 15;
    }
}
