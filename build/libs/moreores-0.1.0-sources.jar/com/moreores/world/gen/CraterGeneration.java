package com.moreores.world.gen;

import com.moreores.registry.ModBlocks;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_7924;

/**
 * Registers surface crater generation in overworld biomes.
 *
 * Craters appear at y=60-80, ~1 per 2500 chunks.
 * Bowl depression replaces surface blocks with moon_rock.
 * Center contains small deposit of moon_rock and rare titanium/platinum ores.
 *
 * This uses a data-driven placed feature referenced by key.
 * The actual feature JSON lives in data/moreores/worldgen/
 */
public class CraterGeneration {

    private static final class_5321<class_6796> MOON_CRATER =
            class_5321.method_29179(class_7924.field_41245, new class_2960("moreores", "moon_crater"));

    public static void register() {
        BiomeModifications.addFeature(
                BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13173,
                MOON_CRATER
        );
    }
}
