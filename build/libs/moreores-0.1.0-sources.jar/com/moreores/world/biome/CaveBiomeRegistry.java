package com.moreores.world.biome;

import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/**
 * Declares {@link class_5321} constants for all 30 custom cave biomes.
 * The actual biome data is provided by the worldgen JSON files under
 * data/moreores/worldgen/biome/. This class exists so that other systems
 * (feature placement, BiomeModifications, etc.) can reference biomes by key
 * without magic strings.
 */
public class CaveBiomeRegistry {

    // -------------------------------------------------------------------------
    // CRYSTAL / GEM CAVES
    // -------------------------------------------------------------------------
    public static final class_5321<class_1959> AMETHYST_CAVE =
            key("amethyst_cave");
    public static final class_5321<class_1959> RUBY_CAVERN =
            key("ruby_cavern");
    public static final class_5321<class_1959> SAPPHIRE_GROTTO =
            key("sapphire_grotto");
    public static final class_5321<class_1959> TOPAZ_HOLLOW =
            key("topaz_hollow");
    public static final class_5321<class_1959> CRYSTAL_PALACE =
            key("crystal_palace");

    // -------------------------------------------------------------------------
    // ORE INDUSTRIAL CAVES
    // -------------------------------------------------------------------------
    public static final class_5321<class_1959> TITANIUM_VEIN =
            key("titanium_vein");
    public static final class_5321<class_1959> PLATINUM_LODE =
            key("platinum_lode");
    public static final class_5321<class_1959> NICKEL_SEAM =
            key("nickel_seam");
    public static final class_5321<class_1959> SILVER_MINE =
            key("silver_mine");
    public static final class_5321<class_1959> TIN_SHAFT =
            key("tin_shaft");

    // -------------------------------------------------------------------------
    // ORGANIC CAVES
    // -------------------------------------------------------------------------
    public static final class_5321<class_1959> FUNGAL_FOREST =
            key("fungal_forest");
    public static final class_5321<class_1959> MOSS_CAVERN =
            key("moss_cavern");
    public static final class_5321<class_1959> ROOT_CAVE =
            key("root_cave");
    public static final class_5321<class_1959> BIOLUMINESCENT_GROTTO =
            key("bioluminescent_grotto");

    // -------------------------------------------------------------------------
    // GEOLOGICAL CAVES
    // -------------------------------------------------------------------------
    public static final class_5321<class_1959> LIMESTONE_CAVERN =
            key("limestone_cavern");
    public static final class_5321<class_1959> MARBLE_HALL =
            key("marble_hall");
    public static final class_5321<class_1959> SLATE_CORRIDOR =
            key("slate_corridor");
    public static final class_5321<class_1959> GRANITE_DOME =
            key("granite_dome");

    // -------------------------------------------------------------------------
    // VOLCANIC CAVES
    // -------------------------------------------------------------------------
    public static final class_5321<class_1959> MAGMA_CHAMBER =
            key("magma_chamber");
    public static final class_5321<class_1959> SULFUR_VENTS =
            key("sulfur_vents");
    public static final class_5321<class_1959> BASALT_CAVERN =
            key("basalt_cavern");
    public static final class_5321<class_1959> OBSIDIAN_VAULT =
            key("obsidian_vault");

    // -------------------------------------------------------------------------
    // FLUID CAVES
    // -------------------------------------------------------------------------
    public static final class_5321<class_1959> OIL_RESERVOIR =
            key("oil_reservoir");
    public static final class_5321<class_1959> BRINE_POOL =
            key("brine_pool");
    public static final class_5321<class_1959> FLOODED_CAVERN =
            key("flooded_cavern");

    // -------------------------------------------------------------------------
    // RUIN / STRUCTURE CAVES
    // -------------------------------------------------------------------------
    public static final class_5321<class_1959> ANCIENT_MINE =
            key("ancient_mine");
    public static final class_5321<class_1959> LOST_VAULT =
            key("lost_vault");
    public static final class_5321<class_1959> COLLAPSED_CITY =
            key("collapsed_city");

    // -------------------------------------------------------------------------
    // DEEP ZONE
    // -------------------------------------------------------------------------
    public static final class_5321<class_1959> DEEP_DARK_EXTENSION =
            key("deep_dark_extension");
    public static final class_5321<class_1959> VOID_EDGE =
            key("void_edge");

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private static class_5321<class_1959> key(String name) {
        return class_5321.method_29179(class_7924.field_41236, new class_2960("moreores", name));
    }

    /**
     * Called from {@code MoreOres.onInitialize()}.
     * The biome data itself is loaded from JSON by the game's dynamic registry.
     * This method forces the static fields to be initialised so the keys are
     * available for feature-registration code that runs immediately after.
     */
    public static void register() {
        // Static field initialisation (triggered by class-load above) is
        // sufficient. Biome objects come from the worldgen data-pack JSONs.
    }
}
