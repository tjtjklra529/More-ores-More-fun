package com.moreores.datagen;

import com.moreores.material.ModMaterials;
import com.moreores.material.OreMaterial;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2444;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2454;
import net.minecraft.class_2960;
import net.minecraft.class_7800;
import net.minecraft.class_7923;
import java.util.function.Consumer;

/**
 * Datagen recipe provider for all moreores materials.
 * Note: Static JSON recipe files under data/moreores/recipes/ are the primary
 * source of truth. This class generates the same recipes programmatically for
 * datagen runs.
 */
public class ModRecipeProvider extends FabricRecipeProvider {

    public ModRecipeProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void method_10419(Consumer<class_2444> exporter) {
        for (OreMaterial mat : ModMaterials.ALL_MATERIALS) {
            generateMaterialRecipes(exporter, mat);
        }
        generateSpecialAlloyRecipes(exporter);
    }

    private void generateMaterialRecipes(Consumer<class_2444> exporter, OreMaterial mat) {
        String name = mat.getName();

        // Smelt/blast raw -> ingot
        if (mat.hasRawItem() && mat.hasIngot()) {
            class_1792 rawItem = getItem("moreores", "raw_" + name);
            class_1792 ingotItem = getItem("moreores", name + "_ingot");
            if (rawItem != null && ingotItem != null) {
                class_2454.method_17802(class_1856.method_8091(rawItem), class_7800.field_40642,
                                ingotItem, 0.7f, 200)
                        .method_10469(FabricRecipeProvider.method_32807(rawItem), FabricRecipeProvider.method_10426(rawItem))
                        .method_17972(exporter, new class_2960("moreores", "smelt_" + name + "_ingot"));
                class_2454.method_10473(class_1856.method_8091(rawItem), class_7800.field_40642,
                                ingotItem, 0.7f, 100)
                        .method_10469(FabricRecipeProvider.method_32807(rawItem), FabricRecipeProvider.method_10426(rawItem))
                        .method_17972(exporter, new class_2960("moreores", "blast_" + name + "_ingot"));
            }
        }

        // Ingot <-> block
        if (mat.hasIngot() && mat.hasStorageBlock()) {
            class_1792 ingotItem = getItem("moreores", name + "_ingot");
            class_1792 blockItem = getItem("moreores", name + "_block");
            if (ingotItem != null && blockItem != null) {
                class_2447.method_10437(class_7800.field_40634, blockItem)
                        .method_10439("III").method_10439("III").method_10439("III")
                        .method_10434('I', ingotItem)
                        .method_10429(FabricRecipeProvider.method_32807(ingotItem), FabricRecipeProvider.method_10426(ingotItem))
                        .method_17972(exporter, new class_2960("moreores", name + "_block_from_ingots"));
                class_2450.method_10448(class_7800.field_40642, ingotItem, 9)
                        .method_10454(blockItem)
                        .method_10442(FabricRecipeProvider.method_32807(blockItem), FabricRecipeProvider.method_10426(blockItem))
                        .method_17972(exporter, new class_2960("moreores", name + "_ingot_from_block"));
            }
        }

        // Gem <-> block
        if (mat.hasGem() && mat.hasStorageBlock()) {
            class_1792 gemItem = getItem("moreores", name);
            class_1792 blockItem = getItem("moreores", name + "_block");
            if (gemItem != null && blockItem != null) {
                class_2447.method_10437(class_7800.field_40634, blockItem)
                        .method_10439("GGG").method_10439("GGG").method_10439("GGG")
                        .method_10434('G', gemItem)
                        .method_10429(FabricRecipeProvider.method_32807(gemItem), FabricRecipeProvider.method_10426(gemItem))
                        .method_17972(exporter, new class_2960("moreores", name + "_block_from_gems"));
                class_2450.method_10448(class_7800.field_40642, gemItem, 9)
                        .method_10454(blockItem)
                        .method_10442(FabricRecipeProvider.method_32807(blockItem), FabricRecipeProvider.method_10426(blockItem))
                        .method_17972(exporter, new class_2960("moreores", name + "_from_block"));
            }
        }

        // Tools
        if (mat.hasTools()) {
            class_1792 material = mat.hasIngot() ? getItem("moreores", name + "_ingot") : getItem("moreores", name);
            if (material != null) {
                offerPickaxeRecipe(exporter, name, material);
                offerAxeRecipe(exporter, name, material);
                offerShovelRecipe(exporter, name, material);
                offerHoeRecipe(exporter, name, material);
            }
        }

        // Sword
        if (mat.hasSword()) {
            class_1792 material = mat.hasIngot() ? getItem("moreores", name + "_ingot") : getItem("moreores", name);
            if (material != null) {
                offerSwordRecipe(exporter, name, material);
            }
        }

        // Dagger
        if (mat.hasDagger()) {
            class_1792 material = mat.hasGem() ? getItem("moreores", name) : getItem("moreores", name + "_ingot");
            if (material != null) {
                offerDaggerRecipe(exporter, name, material);
            }
        }

        // Armor
        if (mat.hasArmor()) {
            class_1792 material = mat.hasGem() ? getItem("moreores", name) : getItem("moreores", name + "_ingot");
            if (material != null) {
                offerArmorRecipes(exporter, name, material);
            }
        }

        // Building blocks
        String blockSource = (mat.hasIngot() || mat.hasGem()) ? name + "_block" : name;
        class_1792 blockItem = getItem("moreores", blockSource);
        if (blockItem != null) {
            if (mat.hasSlabs()) {
                class_1792 slabItem = getItem("moreores", name + "_slab");
                if (slabItem != null) {
                    class_2447.method_10436(class_7800.field_40634, slabItem, 6)
                            .method_10439("BBB")
                            .method_10434('B', blockItem)
                            .method_10429(FabricRecipeProvider.method_32807(blockItem), FabricRecipeProvider.method_10426(blockItem))
                            .method_17972(exporter, new class_2960("moreores", name + "_slab"));
                }
            }
            if (mat.hasStairs()) {
                class_1792 stairsItem = getItem("moreores", name + "_stairs");
                if (stairsItem != null) {
                    class_2447.method_10436(class_7800.field_40634, stairsItem, 4)
                            .method_10439("B  ").method_10439("BB ").method_10439("BBB")
                            .method_10434('B', blockItem)
                            .method_10429(FabricRecipeProvider.method_32807(blockItem), FabricRecipeProvider.method_10426(blockItem))
                            .method_17972(exporter, new class_2960("moreores", name + "_stairs"));
                }
            }
            if (mat.hasWalls()) {
                class_1792 wallItem = getItem("moreores", name + "_wall");
                if (wallItem != null) {
                    class_2447.method_10436(class_7800.field_40634, wallItem, 6)
                            .method_10439("BBB").method_10439("BBB")
                            .method_10434('B', blockItem)
                            .method_10429(FabricRecipeProvider.method_32807(blockItem), FabricRecipeProvider.method_10426(blockItem))
                            .method_17972(exporter, new class_2960("moreores", name + "_wall"));
                }
            }
        }
    }

    private void generateSpecialAlloyRecipes(Consumer<class_2444> exporter) {
        // Bronze: 3 copper + 6 tin -> 4 bronze ingots
        class_1792 copperIngot = class_1802.field_27022;
        class_1792 tinIngot = getItem("moreores", "tin_ingot");
        class_1792 bronzeIngot = getItem("moreores", "bronze_ingot");
        if (tinIngot != null && bronzeIngot != null) {
            class_2450.method_10448(class_7800.field_40642, bronzeIngot, 4)
                    .method_10454(copperIngot).method_10454(copperIngot).method_10454(copperIngot)
                    .method_10454(tinIngot).method_10454(tinIngot).method_10454(tinIngot)
                    .method_10454(tinIngot).method_10454(tinIngot).method_10454(tinIngot)
                    .method_10442(FabricRecipeProvider.method_32807(tinIngot), FabricRecipeProvider.method_10426(tinIngot))
                    .method_17972(exporter, new class_2960("moreores", "bronze_ingot_crafting"));
        }

        // Steel: 1 iron + 4 coal -> 1 steel ingot
        class_1792 steelIngot = getItem("moreores", "steel_ingot");
        if (steelIngot != null) {
            class_2450.method_10448(class_7800.field_40642, steelIngot, 1)
                    .method_10454(class_1802.field_8620)
                    .method_10454(class_1802.field_8713).method_10454(class_1802.field_8713).method_10454(class_1802.field_8713).method_10454(class_1802.field_8713)
                    .method_10442(FabricRecipeProvider.method_32807(class_1802.field_8620), FabricRecipeProvider.method_10426(class_1802.field_8620))
                    .method_17972(exporter, new class_2960("moreores", "steel_ingot_crafting"));
        }

        // Copper alloy: 2 copper + 1 tin -> 3 copper_alloy ingots
        class_1792 copperAlloyIngot = getItem("moreores", "copper_alloy_ingot");
        if (copperAlloyIngot != null && tinIngot != null) {
            class_2450.method_10448(class_7800.field_40642, copperAlloyIngot, 3)
                    .method_10454(copperIngot).method_10454(copperIngot)
                    .method_10454(tinIngot)
                    .method_10442(FabricRecipeProvider.method_32807(tinIngot), FabricRecipeProvider.method_10426(tinIngot))
                    .method_17972(exporter, new class_2960("moreores", "copper_alloy_ingot_crafting"));
        }
    }

    // Tool recipe helpers
    private void offerPickaxeRecipe(Consumer<class_2444> exporter, String name, class_1792 mat) {
        class_1792 pickaxe = getItem("moreores", name + "_pickaxe");
        if (pickaxe == null) return;
        class_2447.method_10437(class_7800.field_40638, pickaxe)
                .method_10439("III").method_10439(" S ").method_10439(" S ")
                .method_10434('I', mat).method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(mat), FabricRecipeProvider.method_10426(mat))
                .method_17972(exporter, new class_2960("moreores", name + "_pickaxe"));
    }

    private void offerAxeRecipe(Consumer<class_2444> exporter, String name, class_1792 mat) {
        class_1792 axe = getItem("moreores", name + "_axe");
        if (axe == null) return;
        class_2447.method_10437(class_7800.field_40638, axe)
                .method_10439("II").method_10439("IS").method_10439(" S")
                .method_10434('I', mat).method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(mat), FabricRecipeProvider.method_10426(mat))
                .method_17972(exporter, new class_2960("moreores", name + "_axe"));
    }

    private void offerShovelRecipe(Consumer<class_2444> exporter, String name, class_1792 mat) {
        class_1792 shovel = getItem("moreores", name + "_shovel");
        if (shovel == null) return;
        class_2447.method_10437(class_7800.field_40638, shovel)
                .method_10439("I").method_10439("S").method_10439("S")
                .method_10434('I', mat).method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(mat), FabricRecipeProvider.method_10426(mat))
                .method_17972(exporter, new class_2960("moreores", name + "_shovel"));
    }

    private void offerHoeRecipe(Consumer<class_2444> exporter, String name, class_1792 mat) {
        class_1792 hoe = getItem("moreores", name + "_hoe");
        if (hoe == null) return;
        class_2447.method_10437(class_7800.field_40638, hoe)
                .method_10439("II").method_10439(" S").method_10439(" S")
                .method_10434('I', mat).method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(mat), FabricRecipeProvider.method_10426(mat))
                .method_17972(exporter, new class_2960("moreores", name + "_hoe"));
    }

    private void offerSwordRecipe(Consumer<class_2444> exporter, String name, class_1792 mat) {
        class_1792 sword = getItem("moreores", name + "_sword");
        if (sword == null) return;
        class_2447.method_10437(class_7800.field_40639, sword)
                .method_10439("I").method_10439("I").method_10439("S")
                .method_10434('I', mat).method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(mat), FabricRecipeProvider.method_10426(mat))
                .method_17972(exporter, new class_2960("moreores", name + "_sword"));
    }

    private void offerDaggerRecipe(Consumer<class_2444> exporter, String name, class_1792 mat) {
        class_1792 dagger = getItem("moreores", name + "_dagger");
        if (dagger == null) return;
        class_2447.method_10437(class_7800.field_40639, dagger)
                .method_10439("I").method_10439("S")
                .method_10434('I', mat).method_10434('S', class_1802.field_8600)
                .method_10429(FabricRecipeProvider.method_32807(mat), FabricRecipeProvider.method_10426(mat))
                .method_17972(exporter, new class_2960("moreores", name + "_dagger"));
    }

    private void offerArmorRecipes(Consumer<class_2444> exporter, String name, class_1792 mat) {
        class_1792 helmet = getItem("moreores", name + "_helmet");
        class_1792 chestplate = getItem("moreores", name + "_chestplate");
        class_1792 leggings = getItem("moreores", name + "_leggings");
        class_1792 boots = getItem("moreores", name + "_boots");

        if (helmet != null) {
            class_2447.method_10437(class_7800.field_40639, helmet)
                    .method_10439("III").method_10439("I I")
                    .method_10434('I', mat)
                    .method_10429(FabricRecipeProvider.method_32807(mat), FabricRecipeProvider.method_10426(mat))
                    .method_17972(exporter, new class_2960("moreores", name + "_helmet"));
        }
        if (chestplate != null) {
            class_2447.method_10437(class_7800.field_40639, chestplate)
                    .method_10439("I I").method_10439("III").method_10439("III")
                    .method_10434('I', mat)
                    .method_10429(FabricRecipeProvider.method_32807(mat), FabricRecipeProvider.method_10426(mat))
                    .method_17972(exporter, new class_2960("moreores", name + "_chestplate"));
        }
        if (leggings != null) {
            class_2447.method_10437(class_7800.field_40639, leggings)
                    .method_10439("III").method_10439("I I").method_10439("I I")
                    .method_10434('I', mat)
                    .method_10429(FabricRecipeProvider.method_32807(mat), FabricRecipeProvider.method_10426(mat))
                    .method_17972(exporter, new class_2960("moreores", name + "_leggings"));
        }
        if (boots != null) {
            class_2447.method_10437(class_7800.field_40639, boots)
                    .method_10439("I I").method_10439("I I")
                    .method_10434('I', mat)
                    .method_10429(FabricRecipeProvider.method_32807(mat), FabricRecipeProvider.method_10426(mat))
                    .method_17972(exporter, new class_2960("moreores", name + "_boots"));
        }
    }

    private class_1792 getItem(String namespace, String path) {
        class_2960 id = new class_2960(namespace, path);
        if (class_7923.field_41178.method_10250(id)) {
            return class_7923.field_41178.method_10223(id);
        }
        return null;
    }
}
