package com.moreores.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_4910;
import net.minecraft.class_4915;

/**
 * Datagen model provider stub.
 * All blockstates, block models, and item models are provided as static JSON files
 * under assets/moreores/. This class exists only to satisfy the datagen entrypoint.
 */
public class ModBlockStateProvider extends FabricModelProvider {

    public ModBlockStateProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 gen) {
        // All blockstate/model JSON files are committed statically — no generation needed.
    }

    @Override
    public void generateItemModels(class_4915 gen) {
        // All item model JSON files are committed statically — no generation needed.
    }
}
