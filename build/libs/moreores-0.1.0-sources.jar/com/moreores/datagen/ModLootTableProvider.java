package com.moreores.datagen;

import com.moreores.material.ModMaterials;
import com.moreores.material.OreMaterial;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Datagen loot table provider for all moreores blocks.
 * Note: Static JSON loot table files under data/moreores/loot_tables/blocks/ are the
 * primary source of truth. This class generates the same tables programmatically.
 */
public class ModLootTableProvider extends FabricBlockLootTableProvider {

    public ModLootTableProvider(FabricDataOutput dataOutput) {
        super(dataOutput);
    }

    @Override
    public void method_10379() {
        for (OreMaterial mat : ModMaterials.ALL_MATERIALS) {
            String name = mat.getName();

            // Ore blocks
            if (mat.hasOre()) {
                class_2248 oreBlock = getBlock("moreores", name + "_ore");
                if (oreBlock != null) {
                    if (mat.hasGem()) {
                        // Gem ore: drop gem with fortune
                        class_1792 gemItem = getItem("moreores", name);
                        if (gemItem != null) method_45988(oreBlock, method_45981(oreBlock, gemItem));
                    } else {
                        // Metal ore: drop raw with fortune
                        class_1792 rawItem = getItem("moreores", "raw_" + name);
                        if (rawItem != null) method_45988(oreBlock, method_45981(oreBlock, rawItem));
                    }
                }
            }

            if (mat.hasDeepslateOre()) {
                class_2248 dsOreBlock = getBlock("moreores", "deepslate_" + name + "_ore");
                if (dsOreBlock != null) {
                    if (mat.hasGem()) {
                        class_1792 gemItem = getItem("moreores", name);
                        if (gemItem != null) method_45988(dsOreBlock, method_45981(dsOreBlock, gemItem));
                    } else {
                        class_1792 rawItem = getItem("moreores", "raw_" + name);
                        if (rawItem != null) method_45988(dsOreBlock, method_45981(dsOreBlock, rawItem));
                    }
                }
            }

            // Storage block (self drop)
            if (mat.hasStorageBlock()) {
                String blockId = (mat.hasIngot() || mat.hasGem()) ? name + "_block" : name;
                class_2248 storageBlock = getBlock("moreores", blockId);
                if (storageBlock != null) method_46025(storageBlock);
            }

            // Slabs (self drop)
            if (mat.hasSlabs()) {
                class_2248 slabBlock = getBlock("moreores", name + "_slab");
                if (slabBlock != null) method_45988(slabBlock, method_45980(slabBlock));
            }

            // Stairs (self drop)
            if (mat.hasStairs()) {
                class_2248 stairsBlock = getBlock("moreores", name + "_stairs");
                if (stairsBlock != null) method_46025(stairsBlock);
            }

            // Walls (self drop)
            if (mat.hasWalls()) {
                class_2248 wallBlock = getBlock("moreores", name + "_wall");
                if (wallBlock != null) method_46025(wallBlock);
            }
        }
    }

    private class_2248 getBlock(String namespace, String path) {
        class_2960 id = new class_2960(namespace, path);
        if (class_7923.field_41175.method_10250(id)) {
            return class_7923.field_41175.method_10223(id);
        }
        return null;
    }

    private class_1792 getItem(String namespace, String path) {
        class_2960 id = new class_2960(namespace, path);
        if (class_7923.field_41178.method_10250(id)) {
            return class_7923.field_41178.method_10223(id);
        }
        return null;
    }
}
