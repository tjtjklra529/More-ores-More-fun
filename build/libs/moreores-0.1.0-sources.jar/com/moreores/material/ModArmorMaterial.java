package com.moreores.material;

import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

/**
 * Implements ArmorMaterial for a given OreMaterial.
 */
public class ModArmorMaterial implements class_1741 {

    private static final int[] BASE_DURABILITY = {11, 16, 15, 13};

    private final OreMaterial material;
    private final class_1856 repairIngredient;

    public ModArmorMaterial(OreMaterial material, class_1856 repairIngredient) {
        this.material = material;
        this.repairIngredient = repairIngredient;
    }

    @Override
    public int method_48402(class_1738.class_8051 type) {
        return BASE_DURABILITY[type.method_48399().method_5927()] * material.getArmorDurabilityMultiplier();
    }

    @Override
    public int method_48403(class_1738.class_8051 type) {
        int[] protection = material.getArmorProtection();
        return switch (type) {
            case field_41934 -> protection[0];
            case field_41935 -> protection[1];
            case field_41936 -> protection[2];
            case field_41937 -> protection[3];
        };
    }

    @Override
    public int method_7699() {
        return material.getToolEnchantability();
    }

    @Override
    public class_3414 method_7698() {
        return class_3417.field_14862;
    }

    @Override
    public class_1856 method_7695() {
        return repairIngredient;
    }

    @Override
    public String method_7694() {
        return "moreores:" + material.getName();
    }

    @Override
    public float method_7700() {
        return material.getArmorToughness();
    }

    @Override
    public float method_24355() {
        return material.getArmorKnockbackRes();
    }
}
