package com.moreores.material;

import net.minecraft.class_1832;
import net.minecraft.class_1856;

/**
 * Implements ToolMaterial for a given OreMaterial.
 */
public class ModToolMaterial implements class_1832 {

    private final OreMaterial material;
    private final class_1856 repairIngredient;

    public ModToolMaterial(OreMaterial material, class_1856 repairIngredient) {
        this.material = material;
        this.repairIngredient = repairIngredient;
    }

    @Override
    public int method_8025() {
        return material.getToolDurability();
    }

    @Override
    public float method_8027() {
        return material.getToolMiningSpeed();
    }

    @Override
    public float method_8028() {
        return material.getToolAttackDamage();
    }

    @Override
    public int method_8024() {
        return material.getMiningLevel();
    }

    @Override
    public int method_8026() {
        return material.getToolEnchantability();
    }

    @Override
    public class_1856 method_8023() {
        return repairIngredient;
    }
}
