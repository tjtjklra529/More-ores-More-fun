package com.moreores.material;

import com.moreores.item.DaggerItem;
import com.moreores.registry.ModBlocks;
import com.moreores.registry.ModItems;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.item.*;

/**
 * Iterates all registered OreMaterials and registers all items/blocks
 * according to the OreBundle flags on each material.
 */
public class MaterialRegistry {

    public static void registerAll(OreMaterial[] materials) {
        for (OreMaterial material : materials) {
            register(material);
        }
    }

    private static void register(OreMaterial material) {
        String name = material.getName();
        float hardness = material.getHardness();
        float resistance = material.getResistance();

        // Determine sound group for storage/building blocks
        // Petrified wood and moon rock use stone sounds, metals use metal sounds
        boolean isStoneType = name.startsWith("petrified_") || name.equals("moon_rock");
        class_2498 primarySound = isStoneType ? class_2498.field_11544 : class_2498.field_11533;

        // Main block (storage block / main material block)
        class_2248 mainBlock = null;
        if (material.hasStorageBlock()) {
            if (isStoneType) {
                mainBlock = ModBlocks.registerStoneBlock(name, hardness, resistance);
            } else {
                mainBlock = ModBlocks.registerStorageBlock(name + "_block", hardness, resistance);
            }
        }

        // Ore blocks
        if (material.hasOre()) {
            ModBlocks.registerOreBlock(name + "_ore", hardness, resistance);
        }
        if (material.hasDeepslateOre()) {
            ModBlocks.registerOreBlock("deepslate_" + name + "_ore", hardness + 1.5f, resistance + 1.5f);
        }

        // Building shapes (use mainBlock as base for stairs)
        class_2248 baseBlock = mainBlock != null ? mainBlock : new class_2248(FabricBlockSettings.method_9637().method_9629(hardness, resistance));

        if (material.hasSlabs()) {
            ModBlocks.registerSlab(name + "_slab", hardness, resistance, primarySound);
        }
        if (material.hasStairs()) {
            ModBlocks.registerStairs(name + "_stairs", baseBlock, hardness, resistance, primarySound);
        }
        if (material.hasWalls()) {
            ModBlocks.registerWall(name + "_wall", hardness, resistance, primarySound);
        }

        // Raw item (vanilla convention: raw_titanium, not titanium_raw)
        if (material.hasRawItem()) {
            ModItems.registerSimple("raw_" + name);
        }

        // Ingot or gem
        class_1792 repairItem = null;
        if (material.hasIngot()) {
            repairItem = ModItems.registerSimple(name + "_ingot");
        } else if (material.hasGem()) {
            repairItem = ModItems.registerSimple(name);
        }

        // Tool and armor materials (built lazily using the repair item once registered)
        final class_1792 finalRepairItem = repairItem;
        class_1856 repairIngredient = finalRepairItem != null
                ? class_1856.method_8091(finalRepairItem)
                : class_1856.field_9017;

        ModToolMaterial toolMaterial = new ModToolMaterial(material, repairIngredient);
        ModArmorMaterial armorMaterial = new ModArmorMaterial(material, repairIngredient);

        // Tools
        if (material.hasTools()) {
            ModItems.register(name + "_pickaxe",
                    new class_1810(toolMaterial, 1, -2.8f, new FabricItemSettings()));
            ModItems.register(name + "_axe",
                    new class_1743(toolMaterial, 6.0f, -3.1f, new FabricItemSettings()));
            ModItems.register(name + "_shovel",
                    new class_1821(toolMaterial, 1.5f, -3.0f, new FabricItemSettings()));
            ModItems.register(name + "_hoe",
                    new class_1794(toolMaterial, -2, 0.0f, new FabricItemSettings()));
        }

        // Sword
        if (material.hasSword()) {
            ModItems.register(name + "_sword",
                    new class_1829(toolMaterial, 3, -2.4f, new FabricItemSettings()));
        }

        // Dagger
        if (material.hasDagger()) {
            ModItems.register(name + "_dagger",
                    new DaggerItem(toolMaterial, 1, -2.0f, new FabricItemSettings()));
        }

        // Armor
        if (material.hasArmor()) {
            ModItems.register(name + "_helmet",
                    new class_1738(armorMaterial, class_1738.class_8051.field_41934, new FabricItemSettings()));
            ModItems.register(name + "_chestplate",
                    new class_1738(armorMaterial, class_1738.class_8051.field_41935, new FabricItemSettings()));
            ModItems.register(name + "_leggings",
                    new class_1738(armorMaterial, class_1738.class_8051.field_41936, new FabricItemSettings()));
            ModItems.register(name + "_boots",
                    new class_1738(armorMaterial, class_1738.class_8051.field_41937, new FabricItemSettings()));
        }
    }
}
