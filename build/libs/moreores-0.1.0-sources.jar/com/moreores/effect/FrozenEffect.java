package com.moreores.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_7923;

/**
 * The Frozen status effect. While active, movement is suppressed via FreezeMixin.
 * This effect is applied by the Freeze enchantment on daggers.
 */
public class FrozenEffect extends class_1291 {

    public static FrozenEffect FROZEN;
    public static class_1291 FREEZE_IMMUNITY;

    public FrozenEffect() {
        super(class_4081.field_18272, 0x88CCFF);
    }

    @Override
    public void method_5572(class_1309 entity, int amplifier) {
        // Movement cancellation is handled by FreezeMixin
        // Zero out velocity every tick to ensure the entity stays still
        entity.method_18800(0, Math.min(entity.method_18798().field_1351, 0), 0);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        // Apply every tick
        return true;
    }

    public static void initialize() {
        FROZEN = new FrozenEffect();
        class_2378.method_10230(class_7923.field_41174, new class_2960("moreores", "frozen"), FROZEN);

        FREEZE_IMMUNITY = new class_1291(class_4081.field_18271, 0xAAFFFF) {
            @Override
            public boolean method_5552(int duration, int amplifier) {
                return false;
            }
        };
        class_2378.method_10230(class_7923.field_41174, new class_2960("moreores", "freeze_immunity"), FREEZE_IMMUNITY);
    }
}
