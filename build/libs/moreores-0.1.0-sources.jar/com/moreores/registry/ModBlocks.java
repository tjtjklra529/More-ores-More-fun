package com.moreores.registry;

import com.moreores.block.engine.OilCrusherBlock;
import com.moreores.block.engine.OilEngineBlock;
import com.moreores.block.engine.OilFurnaceBlock;
import com.moreores.fluid.OilFluid;
import com.moreores.fluid.OilFluidBlock;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2544;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.HashMap;
import java.util.Map;

public class ModBlocks {

    public static final Map<String, class_2248> BLOCKS = new HashMap<>();

    // Oil fluid block
    public static OilFluidBlock OIL_FLUID_BLOCK;

    public static class_2248 register(String name, class_2248 block) {
        class_2248 registered = class_2378.method_10230(class_7923.field_41175, new class_2960("moreores", name), block);
        BLOCKS.put(name, registered);
        // Register block item
        class_2378.method_10230(class_7923.field_41178, new class_2960("moreores", name),
                new class_1747(registered, new FabricItemSettings()));
        return registered;
    }

    public static class_2248 registerNoItem(String name, class_2248 block) {
        class_2248 registered = class_2378.method_10230(class_7923.field_41175, new class_2960("moreores", name), block);
        BLOCKS.put(name, registered);
        return registered;
    }

    public static class_2248 registerOreBlock(String name, float hardness, float resistance) {
        return register(name, new class_2248(FabricBlockSettings.method_9637()
                .method_9629(hardness, resistance)
                .method_29292()
                .method_9626(class_2498.field_11544)));
    }

    public static class_2248 registerStorageBlock(String name, float hardness, float resistance) {
        return register(name, new class_2248(FabricBlockSettings.method_9637()
                .method_9629(hardness, resistance)
                .method_29292()
                .method_9626(class_2498.field_11533)));
    }

    public static class_2248 registerStoneBlock(String name, float hardness, float resistance) {
        return register(name, new class_2248(FabricBlockSettings.method_9637()
                .method_9629(hardness, resistance)
                .method_29292()
                .method_9626(class_2498.field_11544)));
    }

    public static class_2482 registerSlab(String name, float hardness, float resistance, class_2498 sound) {
        class_2482 slab = new class_2482(FabricBlockSettings.method_9637()
                .method_9629(hardness, resistance)
                .method_29292()
                .method_9626(sound));
        register(name, slab);
        return slab;
    }

    public static class_2510 registerStairs(String name, class_2248 baseBlock, float hardness, float resistance, class_2498 sound) {
        class_2510 stairs = new class_2510(baseBlock.method_9564(),
                FabricBlockSettings.method_9637()
                        .method_9629(hardness, resistance)
                        .method_29292()
                        .method_9626(sound));
        register(name, stairs);
        return stairs;
    }

    public static class_2544 registerWall(String name, float hardness, float resistance, class_2498 sound) {
        class_2544 wall = new class_2544(FabricBlockSettings.method_9637()
                .method_9629(hardness, resistance)
                .method_29292()
                .method_9626(sound));
        register(name, wall);
        return wall;
    }

    public static void registerOilFluidBlock() {
        OIL_FLUID_BLOCK = new OilFluidBlock(OilFluid.STILL,
                FabricBlockSettings.method_9637()
                        .method_9632(100f)
                        .method_42327()
                        .method_9634()
                        .method_51177()
                        .method_51371());
        registerNoItem("oil_fluid", OIL_FLUID_BLOCK);
    }

    public static void registerEngineBlocks() {
        register("oil_engine", new OilEngineBlock(FabricBlockSettings.method_9637()
                .method_9629(3.5f, 6f)
                .method_29292()
                .method_9626(class_2498.field_11533)));
        register("oil_furnace", new OilFurnaceBlock(FabricBlockSettings.method_9637()
                .method_9629(3.5f, 6f)
                .method_29292()
                .method_9626(class_2498.field_11544)));
        register("oil_crusher", new OilCrusherBlock(FabricBlockSettings.method_9637()
                .method_9629(3.5f, 6f)
                .method_29292()
                .method_9626(class_2498.field_11544)));
    }

    public static void initialize() {
        registerOilFluidBlock();
        registerEngineBlocks();
    }
}
