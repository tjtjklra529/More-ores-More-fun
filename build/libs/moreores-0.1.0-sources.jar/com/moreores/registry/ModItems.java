package com.moreores.registry;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.HashMap;
import java.util.Map;

public class ModItems {

    public static final Map<String, class_1792> ITEMS = new HashMap<>();

    public static class_1792 register(String name, class_1792 item) {
        class_1792 registered = class_2378.method_10230(class_7923.field_41178, new class_2960("moreores", name), item);
        ITEMS.put(name, registered);
        return registered;
    }

    public static class_1792 registerSimple(String name) {
        return register(name, new class_1792(new FabricItemSettings()));
    }

    public static void initialize() {
        // Items are registered via MaterialRegistry
    }
}
