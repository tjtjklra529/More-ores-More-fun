package com.moreores.registry;

import com.moreores.enchantment.FreezeEnchantment;
import com.moreores.enchantment.PenetratingEnchantment;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModEnchantments {

    public static final FreezeEnchantment FREEZE = new FreezeEnchantment();
    public static final PenetratingEnchantment PENETRATING = new PenetratingEnchantment();

    public static void initialize() {
        class_2378.method_10230(class_7923.field_41176, new class_2960("moreores", "freeze"), FREEZE);
        class_2378.method_10230(class_7923.field_41176, new class_2960("moreores", "penetrating"), PENETRATING);
    }
}
