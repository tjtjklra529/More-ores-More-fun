package com.moreores.registry;

import com.moreores.block.engine.OilCrusherBlock;
import com.moreores.block.engine.OilCrusherBlockEntity;
import com.moreores.block.engine.OilEngineBlock;
import com.moreores.block.engine.OilEngineBlockEntity;
import com.moreores.block.engine.OilFurnaceBlock;
import com.moreores.block.engine.OilFurnaceBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntities {

    public static class_2591<OilEngineBlockEntity> OIL_ENGINE;
    public static class_2591<OilFurnaceBlockEntity> OIL_FURNACE;
    public static class_2591<OilCrusherBlockEntity> OIL_CRUSHER;

    public static void initialize() {
        OIL_ENGINE = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960("moreores", "oil_engine"),
                FabricBlockEntityTypeBuilder.create(OilEngineBlockEntity::new,
                        (net.minecraft.class_2248) ModBlocks.BLOCKS.get("oil_engine")).build()
        );

        OIL_FURNACE = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960("moreores", "oil_furnace"),
                FabricBlockEntityTypeBuilder.create(OilFurnaceBlockEntity::new,
                        (net.minecraft.class_2248) ModBlocks.BLOCKS.get("oil_furnace")).build()
        );

        OIL_CRUSHER = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960("moreores", "oil_crusher"),
                FabricBlockEntityTypeBuilder.create(OilCrusherBlockEntity::new,
                        (net.minecraft.class_2248) ModBlocks.BLOCKS.get("oil_crusher")).build()
        );
    }
}
