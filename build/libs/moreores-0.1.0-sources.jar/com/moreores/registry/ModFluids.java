package com.moreores.registry;

import com.moreores.fluid.OilFluid;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1755;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModFluids {

    public static void initialize() {
        class_2378.method_10230(class_7923.field_41173, new class_2960("moreores", "oil_still"), OilFluid.STILL);
        class_2378.method_10230(class_7923.field_41173, new class_2960("moreores", "oil_flowing"), OilFluid.FLOWING);

        // Register oil bucket
        class_1755 oilBucket = new class_1755(OilFluid.STILL, new FabricItemSettings()
                .method_7896(class_1802.field_8550)
                .method_7889(1));
        class_2378.method_10230(class_7923.field_41178, new class_2960("moreores", "oil_bucket"), oilBucket);
        ModItems.ITEMS.put("oil_bucket", oilBucket);
    }
}
