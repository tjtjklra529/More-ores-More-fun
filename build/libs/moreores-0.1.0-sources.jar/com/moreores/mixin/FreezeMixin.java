package com.moreores.mixin;

import com.moreores.effect.FrozenEffect;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin on LivingEntity to prevent movement while the Frozen effect is active.
 * Injects into travel() to zero out velocity and into jump() to cancel jumping.
 */
@Mixin(class_1309.class)
public abstract class FreezeMixin {

    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void onTravel(class_243 movementInput, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (FrozenEffect.FROZEN != null && self.method_6059(FrozenEffect.FROZEN)) {
            // Allow gravity but cancel horizontal movement
            double currentY = self.method_18798().field_1351;
            self.method_18800(0, Math.min(currentY, 0), 0);
            ci.cancel();
        }
    }

    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    private void onJump(CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (FrozenEffect.FROZEN != null && self.method_6059(FrozenEffect.FROZEN)) {
            ci.cancel();
        }
    }
}
