package com.moreores.enchantment;

import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

/**
 * Penetrating enchantment: deals bonus damage on hit.
 * Only applicable to daggers.
 * Level 1-5: each level adds 0.5 damage (half a heart).
 */
public class PenetratingEnchantment extends class_1887 {

    private static final class_6862<class_1792> DAGGERS_TAG = class_6862.method_40092(class_7924.field_41197, new class_2960("moreores", "daggers"));

    public PenetratingEnchantment() {
        super(class_1888.field_9090, class_1886.field_9074, new class_1304[]{class_1304.field_6173});
    }

    @Override
    public int method_8187() {
        return 1;
    }

    @Override
    public int method_8183() {
        return 5;
    }

    @Override
    public int method_8182(int level) {
        return 5 + (level - 1) * 8;
    }

    @Override
    public int method_20742(int level) {
        return method_8182(level) + 20;
    }

    @Override
    public boolean method_8192(class_1799 stack) {
        return stack.method_31573(DAGGERS_TAG);
    }

    @Override
    public void method_8189(class_1309 user, class_1297 target, int level) {
        if (target instanceof class_1309 livingTarget) {
            // Deal bonus damage: 0.5 per level
            float bonusDamage = level * 0.5f;
            livingTarget.method_5643(user.method_48923().method_48812(user), bonusDamage);
        }
    }
}
