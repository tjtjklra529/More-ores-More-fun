package com.moreores.enchantment;

import com.moreores.effect.FrozenEffect;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

/**
 * Freeze enchantment: applies FrozenEffect on hit.
 * Only applicable to daggers (items with tag moreores:daggers).
 * Level 1-3; each level increases freeze duration by 1 second.
 */
public class FreezeEnchantment extends class_1887 {

    private static final class_6862<class_1792> DAGGERS_TAG = class_6862.method_40092(class_7924.field_41197, new class_2960("moreores", "daggers"));

    public FreezeEnchantment() {
        super(class_1888.field_9088, class_1886.field_9074, new class_1304[]{class_1304.field_6173});
    }

    @Override
    public int method_8187() {
        return 1;
    }

    @Override
    public int method_8183() {
        return 3;
    }

    @Override
    public int method_8182(int level) {
        return 15 + (level - 1) * 9;
    }

    @Override
    public int method_20742(int level) {
        return method_8182(level) + 50;
    }

    @Override
    public boolean method_8192(class_1799 stack) {
        return stack.method_31573(DAGGERS_TAG);
    }

    @Override
    public void method_8189(class_1309 user, class_1297 target, int level) {
        if (target instanceof class_1309 livingTarget) {
            // Don't apply freeze if target has freeze immunity
            if (livingTarget.method_6059(FrozenEffect.FREEZE_IMMUNITY)) {
                return;
            }
            // Apply frozen effect: level seconds (20 ticks per second)
            int freezeDuration = level * 20;
            livingTarget.method_6092(new class_1293(FrozenEffect.FROZEN, freezeDuration, level - 1));

            // Apply freeze immunity for 8.5 seconds to prevent re-freezing immediately
            livingTarget.method_6092(new class_1293(FrozenEffect.FREEZE_IMMUNITY, 170, 0, false, false, false));
        }
    }
}
